set timing on
set echo on
exec load_stage
exec stat_acct_mapping
set echo off 