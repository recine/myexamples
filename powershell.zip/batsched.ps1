

User id: svc_HyperionPl_uat
PS: Hyperi0n

Path where Testbat.bat resides: \\ndcmessu18\d$\Workdata\FIN\02.Batch\
Path where Testbat.bat resides: \\KSTLMESSU22\d$\WorkData\FIN\02.Batch\

Testbat.bat will create txt file within same path.


#_____________________________________________________________________________________

$Username = 'svc_HyperionPl_uat'
$Password = 'Hyperi0n'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass

Try
{
Invoke-Command -ComputerName "KSTLMESSU22" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c '\\KSTLMESSU22\d$\WorkData\FIN\02.Batch\Testbat.bat'"}
Invoke-Command -ComputerName "KSTLMESSU22" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c 'dir \\KSTLMESSU22\d$\WorkData\FIN\02.Batch\'"}
}

Catch 
{
    write-Host "error"
}

#_____________________________________________________________________________________

$Username = 'svc_HyperionPl_uat'
$Password = 'Hyperi0n'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass

Try
{
Invoke-Command -ComputerName "ndcmessu18" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c '\\ndcmessu18\d$\WorkData\FIN\02.Batch\Testbat.bat'"}
Invoke-Command -ComputerName "ndcmessu18" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c 'dir \\ndcmessu18\d$\WorkData\FIN\02.Batch\'"}
}

Catch 
{
    write-Host "error"
}

#_____________________________________________________________________________________
$Username = 'svc_HyperionPl_uat'
$Password = 'Hyperi0n'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList $Username,$pass

Try
{
Invoke-Command -ComputerName "KSTLMESSU22" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c '\\KSTLMESSU22\d$\WorkData\FIN\02.Batch\Testbat.bat'"}
Invoke-Command -ComputerName "KSTLMESSU22" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c 'dir \\KSTLMESSU22\d$\WorkData\FIN\02.Batch\'"}
Invoke-Command -ComputerName "ndcmessu18" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c '\\ndcmessu18\d$\WorkData\FIN\02.Batch\Testbat.bat'"}
Invoke-Command -ComputerName "ndcmessu18" -credential $cred -ErrorAction Stop -ScriptBlock {Invoke-Expression -Command:"cmd.exe /c 'dir \\ndcmessu18\d$\WorkData\FIN\02.Batch\'"}

}

Catch 
{
    write-Host "error"
}