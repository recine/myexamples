#####################################################################################
## Update c:\users\p2731968\mem.log   to the path and log name needed 
## CPU
Get-Date -Format g | out-file -append c:\users\p2731968\cpu.log 
$CPUPercent = @{
  Name = 'CPUPercent'
  Expression = {
    $TotalSec = (New-TimeSpan -Start $_.StartTime).TotalSeconds
    [Math]::Round( ($_.CPU * 100 / $TotalSec), 2)
  }
}
Get-Process -ComputerName $env:computername | 
 Select-Object -Property Name, CPU, $CPUPercent, Description |
 Sort-Object -Property CPUPercent -Descending |
 Select-Object -First 10 |format-table -autosize | out-file -append c:\users\p2731968\cpu.log   
 #######  Memory
Get-Date -Format g | out-file -append c:\users\p2731968\mem.log 
$ProcArray = @()
$Processes = get-process | Group-Object -Property ProcessName
foreach($Process in $Processes)
{
    $prop = @(
            @{n='Count';e={$Process.Count}}
            @{n='Name';e={$Process.Name}}
            @{n='Memory';e={($Process.Group|Measure WorkingSet -Sum).Sum}}
            )
    $ProcArray += "" | select $prop  
}
$ProcArray | sort -Descending Memory | select Count,Name,@{n='Memory usage(Total)';e={"$(($_.Memory).ToString('N0'))Kb"}} | out-file -append c:\users\p2731968\mem.log 
#####################################################################################

