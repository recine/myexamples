Function Get-Folder($initialDirectory)

{
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms")| Out-Null

    $foldername = New-Object System.Windows.Forms.FolderBrowserDialog
    $foldername.rootfolder = "MyComputer"

    if($foldername.ShowDialog() -eq "OK")
    {
        $folder += $foldername.SelectedPath
    }
    return $folder
}

$folderN = Get-Folder


$asm = [System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient") 			
$connectionString = "Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=Stage01;Password=Xtransfer1;Integrated Security=no";			
$oracleConnection = new-object System.Data.OracleClient.OracleConnection($connectionString);
$cmd = new-object System.Data.OracleClient.OracleCommand;
$cmd.Connection = $oracleConnection;
# this is the proc
$cmd.CommandText = "load_atom";
$cmd.CommandType = [System.Data.CommandType]::StoredProcedure;		
$oracleConnection.Open();
Write-Progress -Activity 'Processing Extract Please wait.......' 
$cmd.ExecuteNonQuery() | Out-Null
$oracleConnection.Close();


$dateH = Get-Date -UFormat "%m%d%Y%H%M%S"
$fileN = -join($folderN, '\ATOM_', $dateH, '.csv')
'sep=~'| Out-File $fileN -Append
'REGION_ID~REGION_DESC~MANAGEMENT_AREA~GLID~CARL_ID~CREATED_DATE~SOURCE_DOCUMENT_NBR~NAME~ADDRESS~CITY_NAME~STATE_CODE~ZIP_CODE~JOB_TYPE~JOB_TYPE_DESC~SURVEY_TYPE_ID~SURVEY_TYPE_DESC~PROCESS_STATE~PROCESS_STATE_DESC~DESIGN_STATUS~PROJECT_STATUS~DESIGN_REQUESTED_DATE~HUB_NAME~NODE_ID~NODE_CODE~NODE_NAME~DESIGN_NUMBER~DESIGN_REASON_ID~DESIGN_REASON_DESC~DESIGN_COMPLETE_DATE~DESIGN_TO_DATE~DESIGN_TYPE_ID~DESIGN_TYPE~COAX_DESIGNER_ASSIGNED_DATE~FIBER_DESIGNER_ASSIGNED_DATE~FB_UG_REWORK_EXISTING_FT~FB_AE_REMOVED_FT~CX_AE_FT~CX_AE_OVERLASH_FT~CX_UG_TRENCH_FT~CX_UG_BORE_FT~CX_UG_PULL_THRU_FT~CX_UG_BLDG_ATTCHMNT_FT~CX_UG_OCCUPIED_FT~CX_AE_REWORK_EXISTING_FT~CX_UG_REWORK_EXISTING_FT~CX_AE_REMOVED_FT~AE_VACANT_STRAND_FT~AE_NEW_STRAND_FT~UG_VACANT_STRUCTURE_FT~UG_NEW_VACANT_STRUCTURE_FT~REMOVED_DIRECT_BURY_FT'| Out-File $fileN -Append

$connectionString = "Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=Stage01;Password=Xtransfer1;Integrated Security=no" 
$queryString =     "
select 
REGION_ID,
REGION_DESC,
MANAGEMENT_AREA,
GLID,
CARL_ID,
CREATED_DATE,
SOURCE_DOCUMENT_NBR,
NAME,
ADDRESS,
CITY_NAME,
STATE_CODE,
ZIP_CODE,
JOB_TYPE,
JOB_TYPE_DESC,
SURVEY_TYPE_ID,
SURVEY_TYPE_DESC,
PROCESS_STATE,
PROCESS_STATE_DESC,
DESIGN_STATUS,
PROJECT_STATUS,
DESIGN_REQUESTED_DATE,
HUB_NAME,
NODE_ID,
NODE_CODE,
NODE_NAME,
DESIGN_NUMBER,
DESIGN_REASON_ID,
DESIGN_REASON_DESC,
DESIGN_COMPLETE_DATE,
DESIGN_TO_DATE,
DESIGN_TYPE_ID,
DESIGN_TYPE,
COAX_DESIGNER_ASSIGNED_DATE,
FIBER_DESIGNER_ASSIGNED_DATE,
FB_UG_REWORK_EXISTING_FT,
FB_AE_REMOVED_FT,
CX_AE_FT,
CX_AE_OVERLASH_FT,
CX_UG_TRENCH_FT,
CX_UG_BORE_FT,
CX_UG_PULL_THRU_FT,
CX_UG_BLDG_ATTCHMNT_FT,
CX_UG_OCCUPIED_FT,
CX_AE_REWORK_EXISTING_FT,
CX_UG_REWORK_EXISTING_FT,
CX_AE_REMOVED_FT,
AE_VACANT_STRAND_FT,
AE_NEW_STRAND_FT,
UG_VACANT_STRUCTURE_FT,
UG_NEW_VACANT_STRUCTURE_FT,
REMOVED_DIRECT_BURY_FT
from atom_extract
where rownum < 300
"
[System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient") | Out-Null 
$connection = New-Object System.Data.OracleClient.OracleConnection($connectionString) 
$command = new-Object System.Data.OracleClient.OracleCommand($queryString, $connection) 
$connection.Open() 
$users = $command.ExecuteReader() 
$Counter = $users.FieldCount
$i = 1

  while ($users.Read()) { 
       $col1 = $users["REGION_ID"]
       $col2 = $users["REGION_DESC"]
       $col3 = $users["MANAGEMENT_AREA"]
       $col4 = $users["GLID"]
       $col5 = $users["CARL_ID"]
       $col6 = $users["CREATED_DATE"]
       $col7 = $users["SOURCE_DOCUMENT_NBR"]
       $col8 = $users["NAME"]
       $col9 = $users["ADDRESS"]
       $col10 = $users["CITY_NAME"]
       $col11 = $users["STATE_CODE"]
       $col12 = $users["ZIP_CODE"]
       $col13 = $users["JOB_TYPE"]
       $col14 = $users["JOB_TYPE_DESC"]
       $col15 = $users["SURVEY_TYPE_ID"]
       $col16 = $users["SURVEY_TYPE_DESC"]
       $col17 = $users["PROCESS_STATE"]
       $col18 = $users["PROCESS_STATE_DESC"]
       $col19 = $users["DESIGN_STATUS"]
       $col20 = $users["PROJECT_STATUS"]
       $col21 = $users["DESIGN_REQUESTED_DATE"]
       $col22 = $users["HUB_NAME"]
	   $col23 = $users["NODE_ID"]
       $col24 = $users["NODE_CODE"]
       $col25 = $users["NODE_NAME"]
	   $col26 = $users["DESIGN_NUMBER"]
       $col27 = $users["DESIGN_REASON_ID"]
       $col28 = $users["DESIGN_REASON_DESC"]
       $col29 = $users["DESIGN_COMPLETE_DATE"]
       $col30 = $users["DESIGN_TO_DATE"]
       $col31 = $users["DESIGN_TYPE_ID"]
       $col32 = $users["DESIGN_TYPE"]
       $col33 = $users["COAX_DESIGNER_ASSIGNED_DATE"]
       $col34 = $users["FIBER_DESIGNER_ASSIGNED_DATE"]
       $col35 = $users["FB_UG_REWORK_EXISTING_FT"]
       $col36 = $users["FB_AE_REMOVED_FT"]
       $col37 = $users["CX_AE_FT"]
       $col38 = $users["CX_AE_OVERLASH_FT"]
       $col39 = $users["CX_UG_TRENCH_FT"]
       $col40 = $users["CX_UG_BORE_FT"]
       $col41 = $users["CX_UG_PULL_THRU_FT"]
       $col42 = $users["CX_UG_BLDG_ATTCHMNT_FT"]
       $col43 = $users["CX_UG_OCCUPIED_FT"]
       $col44 = $users["CX_AE_REWORK_EXISTING_FT"]
       $col45 = $users["CX_UG_REWORK_EXISTING_FT"]
       $col46 = $users["CX_AE_REMOVED_FT"]
       $col47 = $users["AE_VACANT_STRAND_FT"]
       $col48 = $users["AE_NEW_STRAND_FT"]
       $col49 = $users["UG_VACANT_STRUCTURE_FT"]
       $col50 = $users["UG_NEW_VACANT_STRUCTURE_FT"]
       $col51 = $users["REMOVED_DIRECT_BURY_FT"]
	   $holdit = -join($col1,'~', $col2,'~', $col3,'~', $col4,'~', $col5,'~', $col6,'~', $col7,'~', $col8,'~', $col9,'~', $col10,'~', $col11,'~', $col12,'~', $col13,'~', $col14,'~', $col15,'~', $col16,'~', $col17,'~', $col18,'~', $col19,'~', $col20,'~', $col21,'~', $col22,'~', $col23,'~', $col24,'~', $col25,'~', $col26,'~', $col27,'~', $col28,'~', $col29,'~', $col30,'~', $col31,'~', $col32,'~', $col33,'~', $col34,'~', $col35,'~', $col36,'~', $col37,'~', $col38,'~', $col39,'~', $col40,'~', $col41,'~', $col42,'~', $col43,'~', $col44,'~', $col45,'~', $col46,'~', $col47,'~', $col48,'~', $col49,'~', $col50,'~', $col51)
	   $holdit |Out-File $fileN  -Append
	   $i++
	   Write-Progress -Activity 'Creating Extract File Please wait.......'  -Status $i;
    }


$connection.Close()
echo " " 
echo " " 
Read-Host -Prompt "Process completed, Extract File Created   Press Enter to exit" 

