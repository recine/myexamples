install-Module -Name ImportExcel -Scope CurrentUser

$csvFile = Import-Csv -Path C:\users\P2731968\FCC\project_details.csv

$csvFile |Get-Member

$csvFile[0].ACTUAL_HOME_PASSED
0

PS C:\Users\P2731968> $csvFile[0].CARL_ID
470000





	
	$i = 0
	$csvFile | ForEach-Object {
        $col1 = $csvFile[$i].CARL_ID
		$col2 = $csvFile[$i].PROJECT_NAME
		$col3 = $csvFile[$i].SURVEY_TYPE
		$col4   = $csvFile[$i].CREATED_DATE
		$col5 = $csvFile[$i].CONST_START_DATE
		$col6 = $csvFile[$i].PROJECT_COMPLETE_DATE
		$col7 = $csvFile[$i].PROJECT_STATUS
		$col8 = $csvFile[$i].DIVISION
		$col9 = $csvFile[$i].OPERATING_UNIT
		$col10 = $csvFile[$i].TAX_UNIT
		$col11 = $csvFile[$i].NEW_NODE
		$col12= $csvFile[$i].HUB_CODE
		$col13 = $csvFile[$i].NODE_CODE
		$col14 = $csvFile[$i].TOTAL_COAX_MILES
		$col15 = $csvFile[$i].TOTAL_FIBER_MILES
		$col16 = $csvFile[$i].TOTAL_MILES
		$col17 = $csvFile[$i].TOTAL_AERIAL_MILES
		$col18 = $csvFile[$i].TOTAL_UG_MILES
		$col19= $csvFile[$i].TOTAL_PASSINGS
		$col20 = $csvFile[$i].ACTUAL_HOME_PASSED
		$col21 = $csvFile[$i].LOTS_PASSINGS
		$col22 = $csvFile[$i].EST_TOTAL_CONSTRUCTION_COST
		$col23 = $csvFile[$i].PROJECT_AUTHORIZATION_TOTAL
		$col24= $csvFile[$i].FIELD_ENGINEER
		$col25= $csvFile[$i].CONST_SUPERVISOR
		$col26 = $csvFile[$i].CONST_MANAGER
	    $holdit = -join($col1,'~',$col2,'~',$col2,'~',$col3,'~',$col4,'~',$col5,'~',$col6,'~',$col7,'~',$col8,'~',$col9,'~',$col10,'~',$col11,'~',$col12,'~',$col13,'~',$col14,'~',$col15,'~',$col16,'~',$col17,'~',$col18,'~',$col19,'~',$col20,'~',$col21,'~',$col22,'~',$col23,'~',$col24,'~',$col25,'~',$col26) 
		echo  $holdit >> c:\users\p2731968\FCC\test.txt
       $i ++
    }
	
	
	
	
	
	
	
	
	
	
CARL_ID
$col2 = $csvFile[$i].PROJECT_NAME
$col3 = $csvFile[$i].SURVEY_TYPE
$col4   = $csvFile[$i].CREATED_DATE
$col5 = $csvFile[$i].CONST_START_DATE
$col6 = $csvFile[$i].PROJECT_COMPLETE_DATE
$col7 = $csvFile[$i].PROJECT_STATUS
$col8 = $csvFile[$i].DIVISION
$col9 = $csvFile[$i].OPERATING_UNIT
$col10 = $csvFile[$i].TAX_UNIT
$col11 = $csvFile[$i].NEW_NODE
$col12= $csvFile[$i].HUB_CODE
$col13 $csvFile[$i].NODE_CODE
$col14 = $csvFile[$i].TOTAL_COAX_MILES
$col15 = $csvFile[$i].TOTAL_FIBER_MILES
$col16 = $csvFile[$i].TOTAL_MILES
$col17 = $csvFile[$i].TOTAL_AERIAL_MILES
$col18 = $csvFile[$i].TOTAL_UG_MILES
$col19= $csvFile[$i].TOTAL_PASSINGS
$col20 = $csvFile[$i].ACTUAL_HOME_PASSED
$col21 = $csvFile[$i].LOTS_PASSINGS
$col22 = $csvFile[$i].EST_TOTAL_CONSTRUCTION_COST
$col23 = $csvFile[$i].PROJECT_AUTHORIZATION_TOTAL
$col24= $csvFile[$i].FIELD_ENGINEER
$col25= $csvFile[$i].CONST_SUPERVISOR
$col26 = $csvFile[$i].CONST_MANAGER




,'~',$col2,'~',$col3,'~',$col4,'~',$col5,'~',$col6,'~',$col7,'~',$col8,'~',$col9,'~',$col10,'~',$col11,'~',$col12,'~',$col13,'~',$col14,'~',$col15,'~',$col16,'~',$col17,'~',$col18,'~',$col19,'~',$col20,'~',$col21,'~',$col22,'~',$col23,'~',$col24,'~',$col25,'~',$col26



