$connectionString = "Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=Stage01;Password=Xtransfer1;Integrated Security=no" 
# $queryString =     "SELECT JOB_ID, Job_header_NAME, JOB_HEAD_CARL_ID FROM super_carl_id where rownum < 6"
$queryString =     "select to_char(time_stamp,'mm/dd/yyyy hh:mi:ss DAY') t_date,error_code,error_message from load_errors order by time_stamp desc"
[System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient") | Out-Null 
$connection = New-Object System.Data.OracleClient.OracleConnection($connectionString) 
$command = new-Object System.Data.OracleClient.OracleCommand($queryString, $connection) 
$connection.Open() 
$users = $command.ExecuteReader() 
 $Counter = $users.FieldCount
 #while ($users.Read()) {  
 #    for ($i = 0; $i -lt $Counter; $i++) { 
 #          @{ $users.GetName($i) = $users.GetValue($i); }  
 #   } 
#	echo '------------'
#}
Get-Date -Format g >> c:\users\p2731968\test.log
echo '_________________________'  >> c:\users\p2731968\test.log
  while ($users.Read()) { 
        $col1 = $users["T_DATE"]
        $col2 = $users["ERROR_CODE"]
        $col3 = $users["ERROR_MESSAGE"]
	   write-host $col1, $col2, $col3  
#	   $holdit = -join($col1,'~', $col2,'~', $col3)
	   $holdit = -join($col1,' ', $col2,' ', $col3)
	   echo $holdit >> c:\users\p2731968\test.log
    }
echo '_________________________'  >> c:\users\p2731968\test.log
echo '    '  >> c:\users\p2731968\test.log

$connection.Close()