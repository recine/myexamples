$asm = [System.Reflection.Assembly]::LoadWithPartialName("System.Data.OracleClient") 			
$connectionString = "Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=Stage01;Password=Xtransfer1;Integrated Security=no";			
$oracleConnection = new-object System.Data.OracleClient.OracleConnection($connectionString);
$cmd = new-object System.Data.OracleClient.OracleCommand;
$cmd.Connection = $oracleConnection;
# this is the proc
$cmd.CommandText = "load_atom";
$cmd.CommandType = [System.Data.CommandType]::StoredProcedure;		
$oracleConnection.Open();
Write-Progress -Activity 'Processing Please wait.......' 
$cmd.ExecuteNonQuery() | out-null;
$oracleConnection.Close();

