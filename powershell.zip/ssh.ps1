Install-Module Posh-SSH -Scope CurrentUser

Get-Command -Module Posh-SSH

New-SSHSession -ComputerName 67.48.243.13 -Credential (Get-Credential)

Invoke-SSHCommand -Index 0 -Command "hostname" | Format-List -Property Output


# eliminates text limit 
$FormatEnumerationLimit=-1
