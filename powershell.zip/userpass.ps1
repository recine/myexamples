Function CustomInputBox([string] $title, [string] $message, [string] $defaultText) 
 {
 $inputObject = new-object -comobject MSScriptControl.ScriptControl
 $inputObject.language = "vbscript" 
 $inputObject.addcode("function getInput() getInput = inputbox(`"$message`",`"$title`" , `"$defaultText`") end function" ) 
 $_userInput = $inputObject.eval("getInput") 
 return $_userInput
 }

$userInput = CustomInputBox "username input box" "Please enter username  " ""
 echo $userInput
$holduser = $userInput

$userInput = CustomInputBox "password input box" "Please enter password  " ""
echo $userInput
echo $holduser"  "$userInput

# $connectionString = "Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=Stage01;Password=Xtransfer1;Integrated Security=no";			
$const = -join("Data Source=67.48.243.13/PRISM03P_svc.CORP.CHARTERCOM.COM;User Id=", $holduser, ";Password=", $userInput, ";Integrated Security=no")
echo $const		