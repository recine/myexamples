#!/usr/bin/env python
import os
from subprocess import Popen, PIPE

outfl = open('/export/home/V731968/ATOM/atom.csv', 'w')
sqlplus = Popen(['sqlplus', '-S', 'stage01/Xtransfer1', '@$HOME/SQL/atom.sql'], stdout=outfl, stdin=PIPE)
out, err = sqlplus.communicate()
print out
os.putenv("outfname", "ATOM_")
os.system("cp $HOME/ATOM/atom.csv $HOME/ATOM/$outfname$(date +%m%d%Y).csv")
