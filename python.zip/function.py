import os
from subprocess import Popen, PIPE

def sqlplusFunc (sqlstr, nbr):
	sqlplus2 = Popen(['sqlplus', '-S', 'stage01/Xtransfer1@67.48.243.13/prism03p_svc.corp.chartercom.com'], stdout=PIPE, stdin=PIPE)
	sqlplus2.stdin.write(sqlstr)
	out, err = sqlplus2.communicate()
	print out
	print nbr
	return;
sqlplusFunc(sqlstr="select count(*) from atom_extract;", nbr=2)





