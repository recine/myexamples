#!/usr/bin/env python
import os
from subprocess import Popen, PIPE

file1=open('/export/home/V731968/PYTHON/test.sql', 'w')
file1.write("select sysdate from dual; \n")
file1.write('exit; \n')
# count = 1
# Code block 1
# while count < 11:
#	print count
#	file1.write(str(count)+'\n')
#	count = count + 1
file1.close()
outfl = open('/export/home/V731968/PYTHON/outsql.txt', 'w')
sqlplus = Popen(['sqlplus', '-S', 'stage01/Xtransfer1', '@/export/home/V731968/PYTHON/test.sql'], stdout=outfl, stdin=PIPE)
out, err = sqlplus.communicate()


#os.system("cp /export/home/V731968/PYTHON/test.txt /export/home/V731968/PYTHON/test.html")
# Code block 2
# if count == 11:
#   print 'Counting complete.'
# from subprocess import call
# call('ls')
# file1.close()




