GlowScript 2.6 VPython
scene.userzoom=False

#The following 2 lines are used to plot things
#gd=graph(xtitle="Time",ytitle="Stuff")
#f1=gcurve()

#ball size
R=0.05

#ball mass
m=15

#gravitational constant - changed for effect
G=6.67e-3
#k=100

#drag coefficient
kv=.2 #this is the velocity drag

#balls at some random location with zero momentum
ballA=sphere(pos=vector(2*random()-1,2*random()-1,0), radius=R)
ballA.m=1
ballA.p=vector(0,0,0)

ballB=sphere(pos=vector(2*random()-1,2*random()-1,0), radius=R)
ballB.m=1
ballB.p=vector(0,0,0)

#time and time step
t=0
dt=0.01

#run the loop for 30 seconds - you can change that if you like
while t<30:
  rate(100) #rate just tells the program how fast to run
  
  #calculate the r vector between the two balls
  r=ballA.pos-ballB.pos
  
  #if the balls overlap, then no force
  if mag(r)<2*R:
    FA=vector(0,0,0)
    FB=vector(0,0,0)
  else:
    FA=-G*ballA.m*ballB.m*norm(r)/mag(r)**2
    FB=-FA
    
  #update the momentum
  ballA.p=ballA.p+FA*dt
  ballB.p=ballB.p+FB*dt
  
  #update the position
  ballA.pos=ballA.pos+ballA.p*dt/ballA.m
  ballB.pos=ballB.pos+ballB.p*dt/ballB.m
  
  #update time
  t=t+dt

#optional graph plotting below (stuff is not real)
#  f1.plot(t,stuff)
