import os
from subprocess import Popen, PIPE
# write to a file with Popen
# use this to write to screen 
# sqlplus = Popen(['sqlplus', 'stage01/Xtransfer1'], stdout=PIPE, stdin=PIPE)
#stage01/Xtransfer1@67.48.243.13/prism03p_svc.corp.chartercom.com


outfl = open('stdout2.txt', 'w')
sqlplus = Popen(['sqlplus', 'stage01/Xtransfer1@67.48.243.13/prism03p_svc.corp.chartercom.com'], stdout=PIPE, stdin=PIPE)
# sqlplus = Popen(['sqlplus', '-S', 'stage01/Xtransfer1'], stdout=outfl, stdin=PIPE)
sqlplus.stdin.write("set heading off"+os.linesep)
sqlplus.stdin.write("set lines 700"+os.linesep)
# sqlplus.stdin.write("select * from super_carl_id where rownum < 5;"+os.linesep)
sqlplus.stdin.write("exec isFoo"+os.linesep)
out, err = sqlplus.communicate()
print out


# os.putenv("outfname", "test_today_")
# os.system("touch $outfname$(date +%m%d%Y).csv")
