import sqlite3
conn = sqlite3.connect('example.db')
c = conn.cursor()

# Create Table
# c.execute('''CREATE TABLE testa (date_time text, how_much real)''')
c.execute('''CREATE index t_date_a on testa (date_time)''')
# Insert a row of data
c.execute("INSERT INTO testa VALUES ('2006-01-05',100)")
conn.commit()
datax = [('2006-01-02',243),
          ('2006-02-02',269),
	  ('2006-09-02',398),
	  ('2017-01-09',34564377)
	]
c.executemany('insert into testa values(?,?)', datax)
conn.commit()
for row in c.execute('select * from testa'):
	print row
conn.close()


# t = ('RHAT',)
# c.execute('SELECT * FROM stocks WHERE symbol=?', t)
# print c.fetchone()
# Larger example that inserts many records at a time
# purchases = [('2006-03-28', 'BUY', 'IBM', 1000, 45.00),
#              ('2006-04-05', 'BUY', 'MSFT', 1000, 72.00),
#             ('2006-04-06', 'SELL', 'IBM', 500, 53.00),
#            ]
# c.executemany('INSERT INTO stocks VALUES (?,?,?,?,?)', purchases)
