import sqlite3
conn = sqlite3.connect('example.db')
c = conn.cursor()

# c.execute("INSERT INTO testa VALUES ('2006-01-05',100)")
# conn.commit()
for row in c.execute('select count(a.qty) from testx a,testa b where a.date = b.date_time order by a.qty'):
	print row
conn.close()


